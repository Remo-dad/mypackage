# mypackage
this library was created as an example of how to publish your own Python package.

## building this package locally
'python setup.py sdist'

## installing this package from Github
'pip install git+https://github.com/James-leslie/example-python-package.git'

## updating this package for Github
'pip install --upgrade git+http://github.com/James-leslie/example-python-package.git'
